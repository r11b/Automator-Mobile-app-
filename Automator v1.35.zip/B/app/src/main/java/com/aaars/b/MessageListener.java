package com.aaars.b;

public interface MessageListener {
    void messageReceived(String message);
}
