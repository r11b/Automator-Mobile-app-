package com.aaars.b;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import static com.aaars.b.Root.USER_ID;

public class UserFragment extends Fragment {
    private List<Notif> notif;
    private RecyclerView rv;
    private UserData userData;
    DatabaseReference dr;

    public UserFragment() { }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_user, container, false);

        RecyclerView rvuser = view.findViewById(R.id.rvuser);
        final TextView tvhead = view.findViewById(R.id.tvhead);
        final TextView tv = view.findViewById(R.id.tv);

        //FIREBASE DATABASE
        FirebaseDatabase database = FirebaseDatabase.getInstance();

        dr = database.getInstance().getReference().child("users").child(USER_ID);
        ValueEventListener postListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()) {
                    userData = dataSnapshot.getValue(UserData.class);
                    tvhead.setText(userData.name);
                    tv.setText(userData.email);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(getContext(), "Failed to load post.", Toast.LENGTH_SHORT).show();
            }
        };
        dr.addValueEventListener(postListener);

        LinearLayoutManager llmuser = new LinearLayoutManager(getContext());
        rvuser.setLayoutManager(llmuser);
        rvuser.setHasFixedSize(true);

        initializeData();

        RVAdapter adapter = new RVAdapter(notif);
        rvuser.setAdapter(adapter);

        return view;
    }

    private void initializeData(){
        notif = new ArrayList<>();
        String s = new String("Android is a mobile operating system developed by Google");
        notif.add(new Notif("Android", s, R.drawable.alpha, ContextCompat.getColor(getContext(), R.color.cyan)));
        notif.add(new Notif("EMail", s, R.drawable.alpha,ContextCompat.getColor(getContext(), R.color.cardGreen)));
        }

    private class RVAdapter extends RecyclerView.Adapter<RVAdapter.DataViewHolder>{

        List<Notif> notif;

        RVAdapter(List<Notif> persons){
            this.notif = persons;
        }

        @Override
        public int getItemCount() {
            return notif.size();
        }

        @Override
        public RVAdapter.DataViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.card_discover, viewGroup, false);
            RVAdapter.DataViewHolder pvh = new RVAdapter.DataViewHolder(v);
            return pvh;
        }

        @Override
        public void onBindViewHolder(RVAdapter.DataViewHolder dataViewHolder, int i) {
            dataViewHolder.header.setText(notif.get(i).header);
            dataViewHolder.desc.setText(notif.get(i).desc);
            dataViewHolder.img.setImageResource(notif.get(i).img);
            dataViewHolder.cv.setCardBackgroundColor(notif.get(i).clr);
        }

        @Override
        public void onAttachedToRecyclerView(RecyclerView recyclerView) {
            super.onAttachedToRecyclerView(recyclerView);
        }

        public class DataViewHolder extends RecyclerView.ViewHolder {
            CardView cv;
            TextView header;
            TextView desc;
            ImageView img;

            DataViewHolder(View itemView) {
                super(itemView);
                cv = itemView.findViewById(R.id.cv);
                header = itemView.findViewById(R.id.header);
                desc = itemView.findViewById(R.id.desc);
                img = itemView.findViewById(R.id.img);
            }
        }
    }
}

class Notif {
    String header;
    String desc;
    int img;
    int clr;

    Notif(String header, String desc, int img, int clr) {
        this.header = header;
        this.desc = desc;
        this.img = img;
        this.clr = clr;
    }
}
